Hi, I'm Hugo!
I worked in this delivery with the help of some colleagues who helped me put it together. 
They had it all working and I couldn't get it, I had a very weird bug or whatever that just doesn't let me render them normally,
The shadows only render when you're moving, they work fine if you do so but they don't work if you are standing still, also they disapear completely after some time.
This is really weird and I don't know why it happens, which is really frustrating especially after trying for basically an entire afternoon, only on the bug.
If you can find a solution I'd love to know it as it was really interesting, aside of how frustrating it was...
Anyway, see you at the final exam!